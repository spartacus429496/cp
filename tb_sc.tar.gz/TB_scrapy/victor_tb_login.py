__author__ = 'CQC'
# -*- coding:utf-8 -*-

import urllib
import urllib2
import cookielib
import re
import tool
import webbrowser
import time
import random

from HTMLParser import HTMLParser
#from htmlentitydefs import name2codepoint

class Request():              
    def __init__(self, url, callback): 
        self.url = url        
        self.callback = callback       

class RedirctHandler(urllib2.HTTPRedirectHandler):
  """docstring for RedirctHandler"""
  def http_error_301(self, req, fp, code, msg, headers):
    pass
  def http_error_302(self, req, fp, code, msg, headers):
    pass
  

#模拟登录淘宝类
class Taobao:

    #初始化方法
    def __init__(self):
	#self.current_shopid = 36339999
	#self.current_shopid = 36340020
	#self.current_shopid = 36341730
	self.current_shopid = 36342008
        #登录的URL
        self.loginURL = "https://login.taobao.com/member/login.jhtml"
        #代理IP地址，防止自己的IP被封禁
        self.proxyURL = 'http://120.193.146.97:843'
        #登录POST数据时发送的头部信息
        self.loginHeaders =  {
            'Host':'login.taobao.com',
            'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20100101 Firefox/35.0',
            'Referer' : 'https://login.taobao.com/member/login.jhtml',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection' : 'Keep-Alive'
        }
        #用户名
        self.username = '15715513873'
        #ua字符串，经过淘宝ua算法计算得出，包含了时间戳,浏览器,屏幕分辨率,随机数,鼠标移动,鼠标点击,其实还有键盘输入记录,鼠标移动的记录、点击的记录等等的信息
        self.ua = '103UW5TcyMNYQwiAiwTR3tCf0J/QnhEcUpkMmQ=|Um5OcktyTXhFfURxSXJPcyU=|U2xMHDJ+H2QJZwBxX39RaFV7W3UpSC5CJVshD1kP|VGhXd1llXGVab1JqU2ZeYFRoX2JAe056RnNJdU9yTnBNcEt1SWcx|VWldfS0QMAswEC4OIBQxByl/KQ==|VmNDbUMV|V2NDbUMV|WGRYeCgGZhtmH2VScVI2UT5fORtmD2gCawwuRSJHZAFsCWMOdVYyVTpbPR99HWAFYVMoRSlIM141SBZPCTlZJFkgCTYOMHtSbVVqJg8wCDd7EW0dcAspVC9GKkdlGHEWfBVyUDtcORAvFyhkGWILZwojHCQbVzZLJkMnRjxBaFdvUBx4GWMeSiBHO1Q0SR18AWwJc1ExTCkHJwkncSc=|WWdHFy0RMQwsECkWKAg9CTcXKxIrFjYCPwIiHiceIwM2DDFnMQ==|WmBAED4QMAwsFyl/KQ==|W2FBET8RMQwsFC4UK30r|XGVFFTtkP3ktVD1HPUMkXzNnW3VVaVRpVXVKf0pqVGhVYFUDVQ==|XWVFFTsVNWVfZ1NzTHdKHDwBIQ8hAT8AOw4xZzE=|XmREFDoUNAgoFikSJhhOGA==|X2dHFzl5LXUJYwZnGkI/VitKIQ8vf0t+Q2NdaFwKKhc3GTcXKREkESVzJQ==|QHpaCiRkMGgUfht6B18iSzZXPBIyDi4QKB0pEkQS|QXhFeFhlRXpaZl9jQ31Ff19nU3NJcVFtUWhIdFRtUHBOelpiQn5AYF5lRXlFZVtiNA=='
        #密码，在这里不能输入真实密码，淘宝对此密码进行了加密处理，256位，此处为加密后的密码
        self.password2 = '7dec75624edf5765b68b8e50e3cfda68b93ac0b20eca0567ba8126ac960799b3701a8fe81d51e73c8916890452fd41932428d84796053872df37e1398dd3e2dbaa5f178ec25e63330effeace4f6b38170afdc5cd69f7436a02afc26ebf7222060ea09424daea8bab9c1e9c84f3491ccc84ee72228ea250f8b93508c40fd70831'
        self.post = post = {
            'ua':self.ua,
            'TPL_username':self.username,
            'TPL_password':'',
            'TPL_checkcode':'',
            'CtrlVersion': '1,0,0,7',
            'TPL_redirect_url':'http://i.taobao.com/my_taobao.htm?nekot=udm8087E1424147022443',
            'loginsite':'0',
            'newlogin':'0',
            'from':'tb',
            'fc':'default',
            'style':'default',
            'css_style':'',
            'tid':'',
            'support':'000001',
            'loginType':'4',
            'minititle':'',
            'minipara':'',
            'umto':'NaN',
            'pstrong':'3',
            'llnick':'',
            'sign':'',
            'need_sign':'',
            'isIgnore':'',
            'full_redirect':'',
            'popid':'',
            'callback':'',
            'guf':'',
            'not_duplite_str':'',
            'need_user_id':'',
            'poy':'',
            'gvfdcname':'10',
            'gvfdcre':'',
            'from_encoding ':'',
            'sub':'',
            'TPL_password_2':self.password2,
            'loginASR':'1',
            'loginASRSuc':'1',
            'allp':'',
            'oslanguage':'zh-CN',
            'sr':'1366*768',
            'osVer':'windows|6.1',
            'naviVer':'firefox|35'
        }
        #将POST的数据进行编码转换
        self.postData = urllib.urlencode(self.post)
        #设置代理
        self.proxy = urllib2.ProxyHandler({'http':self.proxyURL})
        #设置cookie
        self.cookie = cookielib.LWPCookieJar()
        #设置cookie处理器
        self.cookieHandler = urllib2.HTTPCookieProcessor(self.cookie)
        #设置登录时用到的opener，它的open方法相当于urllib2.urlopen
        self.opener = urllib2.build_opener(self.cookieHandler,self.proxy,urllib2.HTTPHandler)
        # self.opener = urllib2.build_opener(self.cookieHandler, urllib2.HTTPHandler)
        #赋值J_HToken
        self.J_HToken = ''
        #登录成功时，需要的Cookie
        self.newCookie = cookielib.CookieJar()
        #登陆成功时，需要的一个新的opener
        self.newOpener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.newCookie), RedirctHandler)
        #引入工具类
        self.tool = tool.Tool()


    #得到是否需要输入验证码，这次请求的相应有时会不同，有时需要验证有时不需要
    def needCheckCode(self):
        #第一次登录获取验证码尝试，构建request
        request = urllib2.Request(self.loginURL,self.postData,self.loginHeaders)
        #得到第一次登录尝试的相应
        response = self.opener.open(request)
        #获取其中的内容
        content = response.read().decode('gbk')
        #获取状态吗
        status = response.getcode()
        #状态码为200，获取成功
        if status == 200:
            print u"获取请求成功"
            #\u8bf7\u8f93\u5165\u9a8c\u8bc1\u7801这六个字是请输入验证码的utf-8编码
            pattern = re.compile(u'\u8bf7\u8f93\u5165\u9a8c\u8bc1\u7801',re.S)
            result = re.search(pattern,content)
            #如果找到该字符，代表需要输入验证码
            if result:
                print u"此次安全验证异常，您需要输入验证码"
                return content
            #否则不需要
            else:
                #返回结果直接带有J_HToken字样，表明直接验证通过
                tokenPattern = re.compile('id="J_HToken" value="(.*?)"')
                tokenMatch = re.search(tokenPattern,content)
                if tokenMatch:
                    self.J_HToken = tokenMatch.group(1)
                    print u"此次安全验证通过，您这次不需要输入验证码"
                    return False
        else:
            print u"获取请求失败"
            return None

    #得到验证码图片
    def getCheckCode(self,page):
        #得到验证码的图片
        pattern = re.compile('<img id="J_StandardCode_m.*?data-src="(.*?)"',re.S)
        #匹配的结果
        matchResult = re.search(pattern,page)
        #已经匹配得到内容，并且验证码图片链接不为空
        if matchResult and matchResult.group(1):
            return matchResult.group(1)
        else:
            print u"没有找到验证码内容"
            return False


    #输入验证码，重新请求，如果验证成功，则返回J_HToken
    def loginWithCheckCode(self):
        #提示用户输入验证码
        checkcode = raw_input('请输入验证码:')
        print checkcode

        #将验证码重新添加到post的数据中
        self.post['TPL_checkcode'] = checkcode

        #对post数据重新进行编码
        self.postData = urllib.urlencode(self.post)
        print self.postData
        try:
            #再次构建请求，加入验证码之后的第二次登录尝试
            request = urllib2.Request(self.loginURL,self.postData,self.loginHeaders)
            #得到第一次登录尝试的相应
            response = self.opener.open(request)
            #获取其中的内容
            content = response.read().decode('gbk')
            #检测验证码错误的正则表达式，\u9a8c\u8bc1\u7801\u9519\u8bef 是验证码错误五个字的编码
            pattern = re.compile(u'\u9a8c\u8bc1\u7801\u9519\u8bef',re.S)
            result = re.search(pattern,content)
            #如果返回页面包括了，验证码错误五个字
            if result:
                print u"验证码输入错误"
                return False
            else:
                #返回结果直接带有J_HToken字样，说明验证码输入成功，成功跳转到了获取HToken的界面
                tokenPattern = re.compile('id="J_HToken" value="(.*?)"')
                tokenMatch = re.search(tokenPattern,content)
                #如果匹配成功，找到了J_HToken
                if tokenMatch:
                    print u"验证码输入正确"
                    self.J_HToken = tokenMatch.group(1)
                    return tokenMatch.group(1)
                else:
                    #匹配失败，J_Token获取失败
                    print u"J_Token获取失败"
                    return False
        except urllib2.HTTPError, e:
            print u"连接服务器出错，错误原因",e.reason
            return False


    #通过token获得st
    def getSTbyToken(self,token):
        tokenURL = 'https://passport.alipay.com/mini_apply_st.js?site=0&token=%s&callback=stCallback6' % token
        request = urllib2.Request(tokenURL)
        response = urllib2.urlopen(request)
        #处理st，获得用户淘宝主页的登录地址
        pattern = re.compile('{"st":"(.*?)"}',re.S)
        result = re.search(pattern,response.read())
        #如果成功匹配
        if result:
            print u"成功获取st码"
            #获取st的值
            st = result.group(1)
            return st
        else:
            print u"未匹配到st"
            return False

    #利用st码进行登录,获取重定向网址
    def loginByST(self,st,username):
        stURL = 'https://login.taobao.com/member/vst.htm?st=%s&TPL_username=%s' % (st,username)
        headers = {
            'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20100101 Firefox/35.0',
            'Host':'login.taobao.com',
            'Connection' : 'Keep-Alive'
        }
        request = urllib2.Request(stURL,headers = headers)
        response = self.newOpener.open(request)
        content =  response.read().decode('gbk')
        #检测结果，看是否登录成功
        pattern = re.compile('top.location = "(.*?)"',re.S)
        match = re.search(pattern,content)
        if match:
            print u"登录网址成功"
            location = match.group(1)
            print "location %s" % location
	    #webbrowser.open_new_tab(location)
	    webbrowser.open(location)
            return True
        else:
            print "登录失败"
            return False


    #获得已买到的宝贝页面
    def getGoodsPage(self,pageIndex):
        goodsURL = 'http://buyer.trade.taobao.com/trade/itemlist/listBoughtItems.htm?action=itemlist/QueryAction&event_submit_do_query=1' + '&pageNum=' + str(pageIndex)
        #goodsURL = 'https://rate.taobao.com/user-rate-UMGHYvFcbMCQT.htm'
        response = self.newOpener.open(goodsURL)
        page =  response.read().decode('gbk')
        print 'victor debug page \n' 
        print page
        print 'victor debug page end !!!!!!!!!!!!!!!!\n\n\n \n' 
        return page

    #获取所有已买到的宝贝信息
    def getAllGoods(self,pageNum):
        print u"获取到的商品列表如下"
        for x in range(1,int(pageNum)+1):
            print 'victor debug page_num !!!!!!!!!!!!!!!!\n\n\n \n' 
            page = self.getGoodsPage(x)
            self.tool.getGoodsInfo(page)
    """
    def start_crawl_task(self,pageNum):
	while request:                                                                                                                                                             
            try:                                                                                                                                                                   
                self.driver.get(request.url)                                                                                                                                       
            except:                                                                                                                                                                
                print "获取页面超时"                                                                                                                                               
                #time.sleep(2)                                                                                                                                                      
                # request = Request(self.next_task_url(), self.shop_basic_info_parse)                                                                                              
            request = request.callback()
    """
    def next_task_url(self):
        self.current_shopid += 1
        url = "https://shop%ld.taobao.com" % self.current_shopid
        print "下一个店铺的地址: %s" % url
        return url
    """
    def current_task_url(self):
        # self.current_shopid += 1
        url = "https://shop%ld.taobao.com" % self.current_shopid
        print "当前店铺的地址 %s" % url
        return url
    def shop_basic_info_parse(self):
	response = self.newOpener.open(goodsURL)
        page =  response.read().decode('gbk')
        print 'victor debug page \n'
        print page
	return Request(self.next_task_url(), self.shop_basic_info_parse)
    """

    #程序运行主干
    def main(self):
        #是否需要验证码，是则得到页面内容，不是则返回False
        needResult = self.needCheckCode()
        #请求获取失败，得到的结果是None
        if not needResult ==None:
            if not needResult == False:
                print u"您需要手动输入验证码"
                checkCode = self.getCheckCode(needResult)
                #得到了验证码的链接
                if not checkCode == False:
                    print u"验证码获取成功"
                    print u"请在浏览器中输入您看到的验证码"
                    # webbrowser.open_new_tab(checkCode)
                    print checkCode
                    self.loginWithCheckCode()
                #验证码链接为空，无效验证码
                else:
                    print u"验证码获取失败，请重试"
            else:
                print u"不需要输入验证码"
        else:
            print u"请求登录页面失败，无法确认是否需要验证码"


        #判断token是否正常获取到
        if not self.J_HToken:
            print "获取Token失败，请重试"
            return
        #获取st码
        st = self.getSTbyToken(self.J_HToken)
        #利用st进行登录
        result = self.loginByST(st,self.username)
        if result:
            #获得所有宝贝的页面
	    """
            page = self.getGoodsPage(1)
            pageNum = self.tool.getPageNum(page)
	    print 'page num:%s'%pageNum 
            if pageNum:
            	self.getAllGoods(pageNum)
  	    """
	    #self.start_crawl_task()
	    #self.start_crawl_task(Request(self.next_task_url(), self.shop_basic_info_parse))
            #hp = lxf_MyHTMLParser()
            hp = MyHTMLParser()
            #file_store = open('file_store.txt','wr')
	    while True:
		url = self.next_task_url()
                #file_store = open('file_store.txt','ar')
		#print url
		try:
		    #response = urllib2.urlopen('http://bbs.csdn.net/why')  
		    response = self.newOpener.open(url)
		    print 'victor debug : response:%s'%response
		    status_code = response.getcode()
		    print 'victor debug : status_code:%s'%status_code

		    #response = self.newOpener.open(url)
		    #statusCode =urllib.urlopen(url).getcode()
		    if status_code == 200:

        	        page =  response.read().decode('gbk')
        	        #page =  response.read().decode('utf-8')
        	        print 'victor debug shop url:%s'%url
            	        #print 'page:%s'%page
                        file_store = open('file_store.txt','ar')
		        file_store.write(url+' --> ')
		        file_store.close()

		        html_code = page

                        #hp = MyHTMLParser()
                        hp.feed(html_code)
		        #file_store.write(hp.real_name)
                        hp.close()
                        #print(hp.links)
                        #print(hp.name.decode('utf-8'))
                        print(hp.name)
                        #print(hp.name.decode('gbk'))
                        #print(hp.content.decode('gbk'))
                        print(hp.content)
		    else:
		        print 'victor debug : status_code:%s'%status_code

	    	    tick = random.randint(2, 10)
	    	    print tick
	    	    #time.sleep(tick)
		#except  URLError , e:
		except urllib2.HTTPError, e:  
		    print e.code  
		except Exception , e:
	            #print 'error:', e 
	            print 'error:%s \n'%e 
		#else:
		#    print 'error happens!\n'
        else:
            print u"登录失败"

 
class MyHTMLParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.links = []
        self.name = []
        self.content = []
	self.realname = u''
 
    def handle_starttag(self, tag, attrs):
        #print "Encountered the beginning of a %s tag" % tag
        if tag == "a":
            if len(attrs) == 0: pass
            else:
                for (variable, value)  in attrs:
                    if variable == "href":
                        self.links.append(value)
        if tag == "meta":
            if len(attrs) == 0: pass
            else:
                for (variable, value)  in attrs:
                    if variable == "name":
			if value == 'description':
		            #[(u'name', u'description'), (u'content', u'\u6dd8\u5b9d, \u5e97\u94fa, \u65fa\u94fa, \u51dd\u7fe0\u7fe1\u7fe0\u6279\u53d1')]
		            try:
			        shop_name = attrs[1]
		                print attrs
		                print shop_name 
				#real_name = shop_name[1]
		                print shop_name[1]
                                file_store = open('file_store.txt','ar')
				#file_store.write(real_name+'\n')
				file_store.write(shop_name[1].encode('utf-8') + '\n')
				file_store.close()
		                #print real_name 

			        #real_name.decode('gbk','ignore').encode('utf-8') 
			        #print real_name 
			
			    except Exception , e:
				#print u'[victor debug]: shopname tag:' + e
				print '[victor debug]: shopname tag:\n' 
				print e
					
			#name_utf = value.decode('gbk')
			#value.decode('gbk','ignore').encode('utf-8') 
			#print name_utf
                        #self.name.append(name_utf)
                        #self.name.append(value)
                    if variable == "content":
			#value.decode('gbk','ignore').encode('utf-8') 
			#content_utf = value.encode('utf8')
                        #self.content.append(content_utf)
                        #self.content.append(value)
			return


class lxf_MyHTMLParser(HTMLParser):

    def handle_starttag(self, tag, attrs):
	return
        #print('<%s>' % tag)

    def handle_endtag(self, tag):
	return
        #print('</%s>' % tag)

    def handle_startendtag(self, tag, attrs):
	return
        #print('<%s/>' % tag)

    def handle_data(self, data):
	return
        #print('data')

    def handle_comment(self, data):
	print data
	return
        #print('<!-- -->')

    def handle_entityref(self, name):
	return
        #print('&%s;' % name)

    def handle_charref(self, name):
	return
        #print('&#%s;' % name)

#parser.feed('<html><head></head><body><p>Some <a href=\"#\">html</a> tutorial...<br>END</p></body></html>') 
#if __name__ == "__main__":
taobao = Taobao()
taobao.main()
