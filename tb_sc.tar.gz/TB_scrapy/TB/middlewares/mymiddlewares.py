from scrapy.exceptions import IgnoreRequest
#from scrapy.contrib.downloadermiddleware import DownloaderMiddleware
from scrapy.contrib.downloadermiddleware.redirect import RedirectMiddleware
class CustomMiddlewares(RedirectMiddleware):
     def process_response(self, request, response, spider):
         #if response.getcode() == 302:
	 request.meta['dont_redirect']=True
	 print request.meta
	 print response 
         """
         print request.meta['redirect_urls'] 
         if request.meta['redirect_urls'] == 'https://store.taobao.com/shop/noshop.htm':
             return IgnoreRequest("victor 302!!")
         else:
             return response
	 """
         #return IgnoreRequest("victor 302!!")
         return response
