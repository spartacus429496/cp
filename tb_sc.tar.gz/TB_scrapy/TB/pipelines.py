# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


# import MySQLdb

import json
class TbPipeline(object):
    def __init__(self):
        #self.file = open('items.jl', 'wb')
        self.file = open('items.jl', 'aw')
    def process_item(self, item, spider):
        line = json.dumps(dict(item)) + "\n"
        self.file.write(line)
	print '\n\nvictor debug :%s\n\n'%item
        return item
'''
    def open_spider(self, spider):
        self.sqlconn = MySQLdb.connect(host='localhost',
                                       port = 3306,
                                       user='root',
                                       passwd='123456',
                                       db ='mj_test')
        self.sqlcur = self.sqlconn.cursor()

    def close_spider(self, spider):
        self.sqlcur.close()
        self.sqlconn.close()
'''
"""
import json

class JsonWriterPipeline(object):

    def __init__(self):
        self.file = open('items.jl', 'wb')

    def process_item(self, item, spider):
        line = json.dumps(dict(item)) + "\n"
        self.file.write(line)
        return item
"""
