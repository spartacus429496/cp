
count = 0
while (count <9):
    #fp = open('test1.txt', 'wr')
    fp = open('test1.txt', 'ar')
    fp.write('hello world \n')
    fp.write('hello world \n')
    fp.close()
    count += 1
    print count
